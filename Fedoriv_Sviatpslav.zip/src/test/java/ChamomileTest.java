import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(Arquillian.class)
public class ChamomileTest {
    @org.junit.Test
    public void isAlive() throws Exception {
    }

    @org.junit.Test
    public void isSmelGood() throws Exception {
    }

    @org.junit.Test
    public void get_price() throws Exception {
    }

    @org.junit.Test
    public void toString() throws Exception {
    }

    @Deployment
    public static JavaArchive createDeployment() {
        return ShrinkWrap.create(JavaArchive.class)
                .addClass(Chamomile.class)
                .addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
    }

}
