import java.util.ArrayList;
import java.util.Scanner;
public class Client {
    private double money;
    private double card;
    public Client(double money,double card) {
        this.money = money;
        this.card = card;
    }

    ArrayList<bouguet> lst = new ArrayList<bouguet>();
    Employee employee =new Employee();
    private void buyBouget(int key){
        System.out.print(employee.shop.toString()+"\n");
        System.out.print("Enter the number of bouget : ");
        int i = Main.scanner.nextInt();
        if (key == 1){
        this.money = this.money - employee.shop.lst.get(i).get_price();}
        else{
            this.card = this.card - employee.shop.lst.get(i).get_price();
        }
        lst.add(employee.shop.lst.get(i));
        employee.deleteBuquet(i);

    }
    @Override
    public String toString(){
        String s;
        StringBuilder new_string = new StringBuilder();
        for(int i = 0; i<lst.size();i++){
            new_string.append(lst.get(i).toString());
        }
        new_string.append("\n"+"The money that client has == "+this.money);
        s = new_string.toString();
        return s;
    }
    public void buyByCardOrCash(){
        System.out.print("Card or cash : ");
        int key = Main.scanner.nextInt();
        switch (key){
            case 1:{
                buyBouget(key);
                break;}
            case 2:{
                buyBouget(key);
                break;
            }
        }
    }
    public void makeNewBouget() {
        employee.addNewBuquet();
        buyByCardOrCash();
    }
    public void addFlowerToBouget(){
        employee.addNewPlant();
    }

    public void DeleteFlowerFromBouget(){
        employee.deleteFlower();
    }
}