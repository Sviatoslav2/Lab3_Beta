import com.sun.org.apache.xpath.internal.functions.FuncFalse;
import java.util.Scanner;
public class Main {
    public static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args){
        //public Client client = Client();
    }
}
