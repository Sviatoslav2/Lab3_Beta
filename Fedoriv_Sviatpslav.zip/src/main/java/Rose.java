public class Rose extends Flower {
    public Rose(int len,boolean smel,boolean isAlive,float price_of_Rose) {
        isAlive = isAlive;
        smel = smel;
        length = len;
        price = price_of_Rose;
    }
    public boolean isAlive(){
        return isAlive;
    }
    public boolean isSmelGood(){
        return smel;
    }
    public float get_price(){return price;}
    @Override
    public String toString(){
        String s = new String("***It is rose***"+"\n"+"It is alive == " + isAlive()+"."+"\n"+"It is smel good == " + isSmelGood()+"."+"\n"+"Length of flower == "+length+"\n"+"The price == "+get_price());
        return s;
    }
}
