import com.sun.security.ntlm.Client;
import java.util.Scanner;
import java.util.ArrayList;

public class Shop {
    ArrayList<bouguet> lst = new ArrayList<bouguet>();
    public void adNewBouguet(bouguet NewBouguet){
        lst.add(NewBouguet);
    }
    private void deleteBouguet(bouguet OldBouguet){
        lst.remove(OldBouguet);
    }
    public String ShowShop(){
        String str;
        StringBuilder s = new StringBuilder();
        for(int i = 0; i<lst.size();i++){
            s.append(lst.get(i).toString());
        }
        str = s.toString();
        return str;
    }
    public void construct(){
        bouguet NewBouguet = new bouguet();
        int key ;
        String work="Work hard!!!";
        while (work.equals("Work hard!!!")) {
            System.out.print("Enter the number(1,2,3) rose, tulip, chamomile or 4 to end : ");
            key = Main.scanner.nextInt();
            switch (key) {
                case 1:{
                    System.out.print("Enter the length of flower: ");
                    int length =  Main.scanner.nextInt();
                    Tulip tulip = new Tulip(length,true,true, (float) 10.0);
                    NewBouguet.add_to_bouguet(tulip);
                    break;
                }
                case 2:{
                    System.out.print("Enter the length of flower: ");
                    int length =  Main.scanner.nextInt();
                    Rose rose = new Rose(length,true,true, (float) 20.0);
                    NewBouguet.add_to_bouguet(rose);
                    break;
                }
                case 3:{
                    System.out.print("Enter the length of flower: ");
                    int length =  Main.scanner.nextInt();
                    Chamomile chamomile = new Chamomile(length,true,true, (float) 30.0);
                    NewBouguet.add_to_bouguet(chamomile);
                    break;
                }
                case 4:{
                    work = "Stop working!!!";
                    break;
                }
            }
        }
        lst.add(NewBouguet);
    }
    @Override
    public String toString(){
        String s = new String();
        StringBuilder new_str = new StringBuilder();
        for(int i = 0; i<lst.size();i++){
            new_str.append(lst.get(i).toString()+"\n");
        }
        s = new_str.toString();
        return s;

    }

}
