public class Employee {
    public Shop shop = new Shop();
    public void addNewPlant() {
        System.out.print(shop.toString()+"\n");
        System.out.print("Enter the number of bouget : ");
        int i = Main.scanner.nextInt();
        System.out.print("\n"+"Chamomile,rose,tulip (1,2,3):");
        int key = Main.scanner.nextInt();
        System.out.print("\n"+"Enter the length of flower : ");
        int length = Main.scanner.nextInt();
        switch (key){
            case 1:{
                Chamomile chamomile = new Chamomile(length,true,true,10);
                shop.lst.get(i).lst.add(chamomile);
                break;
            }
            case 2:{
                Rose rose = new Rose(length,true,true,10);
                shop.lst.get(i).lst.add(rose);
                break;
            }
            case 3:{
                Tulip tulip = new Tulip(length,true,true,10);
                shop.lst.get(i).lst.add(tulip);
                break;
            }
        }

    }
    public void deleteFlower(){
        System.out.print(shop.toString()+"\n");
        System.out.print("Enter the number of bouget : ");
        int i = Main.scanner.nextInt();
        System.out.print("\n"+"Enter the number of flower : ");
        int number_flower = Main.scanner.nextInt();
        shop.lst.get(i).lst.get(number_flower);
    }
    public void addNewBuquet(){
        shop.construct();
    }
    public void deleteBuquet(int i){ shop.lst.remove(shop.lst.get(i)); }
}
