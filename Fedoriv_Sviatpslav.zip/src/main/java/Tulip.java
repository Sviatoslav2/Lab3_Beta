public class Tulip extends Flower {
    public Tulip(int len,boolean smel,boolean isAlive,float price_of_Tulip) {
        isAlive = isAlive;
        smel = smel;
        length = len;
        price = price_of_Tulip;
    }
    public boolean isAlive(){ return isAlive; }
    public boolean isSmelGood(){
        return smel;
    }
    public float get_price(){return price;}
    @Override
    public String toString(){
        String s = new String("***It is tulip***"+"\n"+"It is alive == " + isAlive()+"."+"\n"+"It is smel good == " + isSmelGood()+"."+"\n"+"Length of flower == "+length+"\n"+"The price == "+get_price());
        return s;
    }

}
